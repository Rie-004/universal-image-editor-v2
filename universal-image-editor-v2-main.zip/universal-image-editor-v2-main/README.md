# universal-image-editor-v2
Aplikasi gabung screenshot, OCR otomatis, dan export ke PDF/Word. Tampilan Android.
